module WritingHelper
end
