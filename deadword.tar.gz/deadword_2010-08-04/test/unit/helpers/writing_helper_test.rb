require 'test_helper'

class WritingHelperTest < ActionView::TestCase
end
